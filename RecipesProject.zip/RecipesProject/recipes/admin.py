from django.contrib import admin
from .models import recipe
# Register your models here.
admin.site.register(recipe)