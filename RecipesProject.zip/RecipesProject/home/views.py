from django.shortcuts import render,redirect
from recipes.models import recipe
from django.views.generic import TemplateView

# Create your views here.


class Home(TemplateView):
    context = {}
    template_name = 'home/home.html'

    def get(self, request, *args, **kwargs):
        user = request.user.id
        if user:
            return redirect('userhome')
        data = recipe.objects.all()
        self.context['data'] = data
        return render(request,self.template_name , self.context)
    
from django.db.models import Q
from django.views.generic import ListView
from recipes.models import recipe

class SearchRecipe(ListView):
    model = recipe
    template_name = 'home/home.html'
    context_object_name = 'recipes'
    paginate_by = 10  # adjust as needed

    def get_queryset(self):
        query = self.request.GET.get('q')
        object_list = recipe.objects.filter(
            Q(recipe_name__icontains=query) | Q(ingredient__icontains=query) | Q(How_to_make__icontains=query)
        )
        return object_list

